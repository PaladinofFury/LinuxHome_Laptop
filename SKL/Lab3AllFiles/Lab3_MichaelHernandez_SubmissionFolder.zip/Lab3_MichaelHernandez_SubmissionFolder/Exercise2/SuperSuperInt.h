#include <string>
#include "SuperInt.h"

class SuperSuperInt : public SuperInt {
 public:
    const int& theValue();

 private:
    
};